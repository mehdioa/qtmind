QtMind
=========

QtMind is a Mastermid game in Qt, with built in solver. Most of the major solving algorithms are integrated in QtMind.
