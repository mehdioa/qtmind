#!/bin/bash

uid=`id -u`

if [ $uid -ne 0 ]; then 
    echo "You must be root to run this"
    exit 1
fi

arch=`uname -m`
pkgname="qtmind"
printf
echo "This script install/remove $pkgname from your system"
printf 'Do you want to install/remove/none [i/r/N]: '
read ans
case ${ans:=i} in [iIrRnN]*) ;; *) exit ;; esac
if [ $ans == i ] || [ $ans == I ]; then
	echo "This script installs $pkgname on your GNU/Linux $arch system"

	if [ ${arch} == 'x86_64' ]; then
		install -D -m755 "$pkgname-x86_64" /usr/bin/"$pkgname"
	else
		install -D -m755 "$pkgname-i686" /usr/bin/"$pkgname"
	fi
	install -d /usr/share/"$pkgname"
	cp -r translations/ /usr/share/"$pkgname"
	install -D -m644 "$pkgname.png" /usr/share/pixmaps/"$pkgname.png"
	install -D -m644 "$pkgname.desktop" /usr/share/applications/"$pkgname.desktop"
	update-desktop-database -q
	echo "$pkgname is successfully installed"
	exit 1
elif [ $ans == r ] || [ $ans == R ]; then

	rm /usr/bin/$pkgname
	rm -r /usr/share/$pkgname
	rm /usr/share/pixmaps/$pkgname.png
	rm /usr/share/applications/$pkgname.desktop
	update-desktop-database -q
	echo "$pkgname successfully removed"
	exit 1
else
	echo "usage: setup-qtmind <install, remove>"
	exit 1
fi
