QtMind
=========

QtMind is a Mastermid game in Qt, with built in solver. Most of the major solving algorithms are integrated in QtMind.

QtMind links:

- http://omidnikta.github.io/qtmind/index.html		-- Home Page
- http://omidnikta.github.io/qtmind/downloads.html 	-- Binary Downloads
- http://omidnikta.github.io/qtmind/translate.html	-- Translate QtMind


